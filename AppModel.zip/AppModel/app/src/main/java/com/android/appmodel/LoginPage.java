package com.android.appmodel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class LoginPage extends AppCompatActivity {

    TextView toRegisterPage;
    MaterialButton toMainActivity;
    TextInputEditText loginEmail, loginPassword;
    private ProgressBar loginProgress;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        //auth user
        mAuth = FirebaseAuth.getInstance();
        //functions
        visibilityComponent();
        intentRegisterPage();
        intentMainActivity();
    }
    public void intentRegisterPage(){
        toRegisterPage = findViewById(R.id.toRegister);
        toRegisterPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toRegister = new Intent(getApplicationContext(), RegisterPage.class);
                startActivity(toRegister);
            }
        });
    }
    public void intentMainActivity(){
        toMainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginProgress.setVisibility(View.VISIBLE);
                toMainActivity.setVisibility(View.INVISIBLE);

                final String email = loginEmail.getText().toString();
                final String password = loginPassword.getText().toString();

                if (email.isEmpty() || password.isEmpty()) {
                    showMessage("Please Verify All Field");
                    toMainActivity.setVisibility(View.VISIBLE);
                    loginProgress.setVisibility(View.INVISIBLE);
                }else
                {
                    signIn(email,password);
                }
            }
        });
    }
    private void signIn(String mail, String password) {
        mAuth.signInWithEmailAndPassword(mail,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    loginProgress.setVisibility(View.INVISIBLE);
                    toMainActivity.setVisibility(View.VISIBLE);
                    Intent intent = new  Intent(getApplicationContext(), ShowLogin.class);
                    startActivity(intent);
                }else {
                    toMainActivity.setVisibility(View.VISIBLE);
                    loginProgress.setVisibility(View.INVISIBLE);
                }
            }
        });
    }
    private void showMessage(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }

    private void visibilityComponent(){
        loginEmail = findViewById(R.id.email_login);
        loginPassword = findViewById(R.id.password_login);
        toMainActivity = findViewById(R.id.btnEnter);
        loginProgress = findViewById(R.id.progress_login);
        loginProgress.setVisibility(View.INVISIBLE);

    }
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();

        if(user != null) {
            Intent intent = new  Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
    }
}
