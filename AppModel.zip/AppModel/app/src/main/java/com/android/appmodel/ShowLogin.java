package com.android.appmodel;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ShowLogin extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    //private TextView userName;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_auth_success);
        //mAuth = FirebaseAuth.getInstance();
        //currentUser = mAuth.getCurrentUser();
        //userData();
        toHomePage();
    }

    private void toHomePage(){
        shakeItBaby();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent toHome = new Intent(getApplicationContext(), LoginPage.class);
                startActivity(toHome);
            }
        },3900);
    }

    private void userData(){
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        //userName = findViewById(R.id.showName);
        //userName.setText(currentUser.getDisplayName());
    }
    private void shakeItBaby() {
        if (Build.VERSION.SDK_INT >= 26) {
            ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(VibrationEffect.createOneShot(150,10));
        } else {
            ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(150);
        }
    }
}
