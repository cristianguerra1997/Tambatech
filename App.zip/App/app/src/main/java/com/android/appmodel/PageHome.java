package com.android.appmodel;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.google.android.material.button.MaterialButton;

public class PageHome extends AppCompatActivity {

    MaterialButton buttonToLoginPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_home);

        intentLoginPage();
    }

    public void intentLoginPage(){
        buttonToLoginPage = findViewById(R.id.btnGetStarted);
        buttonToLoginPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toLogin = new Intent(getApplicationContext(), LoginPage.class);
                startActivity(toLogin);
            }
        });
    }
}